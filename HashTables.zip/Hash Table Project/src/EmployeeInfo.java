
   

public class EmployeeInfo {
	
	
	int empNumber;
	String firstName;
	String lastName;
	double deductionsRate;
	
	public EmployeeInfo (int eN, String fN, String lN, double dR) {
		empNumber = eN;
		firstName = fN;
		lastName = lN;
		deductionsRate = dR;
	}
	
}